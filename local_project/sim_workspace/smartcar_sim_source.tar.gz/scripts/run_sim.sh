#!/usr/bin/env bash
set -e
cd "$(dirname "$0")/.."
source scripts/source_env.sh
exec roslaunch smartcar_bringup simulation.launch "$@"
