# Source this file from Bash; no .bashrc changes required.
source /opt/ros/kinetic/setup.bash
_inspection_ws="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
if [ -f "$_inspection_ws/devel/setup.bash" ]; then source "$_inspection_ws/devel/setup.bash"; fi
export GAZEBO_PLUGIN_PATH="$_inspection_ws/devel/lib${GAZEBO_PLUGIN_PATH:+:$GAZEBO_PLUGIN_PATH}"
unset _inspection_ws
