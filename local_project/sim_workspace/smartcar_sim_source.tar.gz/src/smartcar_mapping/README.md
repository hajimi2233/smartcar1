Cartographer is not installed or configured by this generator. data/maps/sim_field_v1/map.yaml is generated from world wall geometry, not from lidar mapping.
