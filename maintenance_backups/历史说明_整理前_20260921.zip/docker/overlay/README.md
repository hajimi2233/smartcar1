# docker/overlay — 本仓库改过的全部源码母本

这些文件是宿主机上的真源。容器 `smartcar-sim` 里 `/home/hajimi/smartcar_2026_ws/` 是运行副本。改这里再 `docker cp` 进去。

当前定位 launch 实际启动的是：`laser_noise.py`、`imu_bridge.py`、官方 `laser_scan_matcher_node`、官方 `amcl`、`scan_in_map.py`。车辆没有轮速里程计，局部 `odom` 由激光扫描匹配生成并由 IMU 约束。

## 当前在用

| 文件 | 作用 |
|---|---|
| `localization.launch` | 定位入口：地图 + 雷达噪声 + IMU + laser_scan_matcher + AMCL + 红点云 |
| `amcl.launch` | 官方 amcl，scan 订 `/scan` |
| `localization.yaml` | AMCL / 激光-IMU前端 / 激光噪声参数 |
| `laser_noise.py` | `/sim/scan` → `/scan`；`sensors.ideal` 时原样转发 |
| `scan_in_map.py` | 用 `/amcl_pose` 把 `/scan` 投到 map，RViz 红点 |
| `inspection.rviz` | RViz 配置，Fixed Frame=`map` |
| `simulation.launch` | 仿真启动；几何图 remap 到 `/geometry_map`，避免抢 `/map` |
| `keyboard.sh` / 见 templates/teleop.py | 按住 WASD 开车，发 `/sim/cmd_vel` |
| `start_gzclient.sh` | 软件 GL 开 Gazebo 窗口 |
| `start_localization.sh` | 容器内启动定位 |
| `reset_to_start.sh` `reset_to_start.py` | 车放回 (3.86, 2.80, yaw=π) |
| `gmapping.launch` `start_mapping.sh` `save_map.sh` | 建图存图 |
| `waypoint_marker.py` `mark_points.sh` | 在地图上标 26 个点 |
| `inspection_car.urdf` | 当前车模；第一层 IMU 是 `/sim/imu`，由 `imu_bridge.py` 转为 `/imu/data` |
| `smartcar_navigation.CMakeLists.txt` | 安装 python 脚本到 devel |

## 留档（launch 默认不启动）

| 文件 | 作用 |
|---|---|
| `imu_bridge.py` | 仿真 IMU 适配：`/sim/imu` → `/imu/data`，不读取真值和轮速 |
| `scan_match_localizer.py` | 自制雷达定位（已弃用，用户要求改用开源 CSM） |
| `waypoint_nav.py` `navigation.launch` | 按点导航草稿 |

## 物理插件（不在 overlay 根目录）

`../../local_project/sim_workspace/templates/ackermann_plugin.cpp`  
标准 Ackermann：左右前轮使用不同转角，四个轮子使用符合转弯半径的不同理论速度；机械限位只在初始化时设置，不发 `sim_world→base_footprint` TF（`publish_tf=0`）。定位只使用激光和 IMU，`odom` 由 `laser_scan_matcher` 产生。改完在容器 `catkin_make --pkg smartcar_sim smartcar_navigation` 后 **docker restart**。标准模型源码的唯一母本是 `local_project/sim_workspace/templates/ackermann_plugin.cpp`。

生成 URDF/launch 的脚本：`../../local_project/sim_workspace/generate.py`（IMU 话题 `/sim/imu`）。
