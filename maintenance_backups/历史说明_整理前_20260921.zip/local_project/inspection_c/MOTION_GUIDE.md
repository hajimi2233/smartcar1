# V6：26 点坐标导入与进退指令

## 使用

1. 关闭旧窗口，双击 `run.cmd`，确认显示 V6。
2. 输入 `A1B2A3B4`，查看巡检顺序和目标表。
3. 把建图组提供的 `map_info.txt`、`points.csv` 替换到程序目录。
4. 在程序中输入 `r` 重新导入。每次输入 A/B 编号生成新计划前也会自动重读，修改坐标无需编译或重启。

导入失败时显示错误，本次不生成任务，不以旧坐标悄悄继续。修正文件后可以再次输入。启动时文件错误则退出，修正后重开。成功计算会覆盖 `motion_commands.jsonl`；输入或导入失败时，该文件仍为上次成功结果，不代表新任务。

文件格式和全部点名见《建图组点位数据交接说明.md》。自带文件是演示坐标，`frame_id=map_demo`。旧 `motion_map.txt` 不再读取。

命令行也支持指定其他位置的一对文件：

```powershell
.\inspection_planner_v6.exe "A1B2A3B4" "D:\比赛数据\map_info.txt" "D:\比赛数据\points.csv"
```

输出文件写入当前工作目录；通过 `run.cmd` 启动时就是程序目录。

## 点位与简化动作

点位仅含名称、x、y，共 26 个。所有目标使用前轴中点为参考。巡检点是每区唯一的中心点，从两个方向进入共用同一坐标。程序使用本列两个通道外入口坐标推导朝向，因此地图整体旋转不影响这个计算。

| 阶段 | 行为 | 模式 |
|---|---|---|
| ALIGN | 在通道外入口点对齐车头，准备进入 | AUTO |
| INSPECT | 前进到巡检区中心并等待巡检完成 | FORWARD_ONLY |
| PASS | 通过通道，前进到另一端的通道外入口点 | FORWARD_ONLY |
| RETREAT | 原路倒车到通道外入口点，不重复播报 | REVERSE_ONLY |
| OUTER | 公共区外部绕行 | AUTO |
| EXIT | 前往导入的终点 | AUTO |

不再生成 ENTER、CLEAR 或列内连接点停车指令；枚举旧值仅为源码兼容保留。通道外入口点同时承担准备和退出功能。

`A1B2A3B4` 现在生成 11 条命令：

```text
col1_top_entry   ALIGN     AUTO
inspect_1        INSPECT   FORWARD_ONLY
inspect_2        INSPECT   FORWARD_ONLY
col1_top_entry   RETREAT   REVERSE_ONLY
col2_top_entry   ALIGN     AUTO
inspect_3        INSPECT   FORWARD_ONLY
inspect_4        INSPECT   FORWARD_ONLY
col2_top_entry   RETREAT   REVERSE_ONLY
map_right_top    OUTER     AUTO
map_right_bottom OUTER    AUTO
end              EXIT      AUTO
```

从 2 倒车到入口会经过已检的 1，但不在 1 或列内连接点额外停车。完整拓扑行程仍显示 `(1)`，以说明借道关系。B 的含义仍是到其中心巡检后退出，不是把 B 中心当作不能触及的障碍。

## 起终点、地图与几何限制

- `start` 从 CSV 读取并写入计划信息，不再固定为 1 外的入口。车应已在该起点附近，初始姿态和定位由执行端提供；程序不会先命令车回起点。
- 原路线起始侧仍是上方公共区，终点必须从下方公共区可达。仅更换坐标不会自动改变这套拓扑。
- 每列是直通道，两个巡检中心需依次位于两入口之间，距入口连线的垂距不超过 0.05 米。这个导入校验阈值不是车辆定位精度、控制容差或安全距离。
- 输入数据可旋转、平移，列间距也可不同；原先的补检顺序仍以列号差判断远近，尚未按实际米数重新优化。
- 没有墙体地图、车辆轮廓或转弯半径的几何验证，不能仅凭导入成功认定实车路径可行。

## 给导航执行组

ROS1 接口草案为 `ros1_interface/ExecuteMotion.action`，未提供 ROS 构建或执行服务端。本机仅编译纯 C 规划程序。

- `target_id` 现在是固定点名，同一位置可以多次出现；单条命令以本轮 `task_id` 区分，跨轮以 `mission_id` 区分。
- `map_id`、`map_version`、`frame_id` 来自元数据文件。`target_reference=front_axle_midpoint` 必须落实到目标参考点转换。
- `yaw_rad` 是程序从入口推导的车头朝向，用户不需要填写。`enforce_yaw=true` 用于入口对齐和通道段；OUTER、EXIT 为 false，其 yaw 占位值应忽略，不能强制最终朝向为 0。
- `AUTO + PUBLIC_ONLY` 只在公共区导航，不允许为抄近路进入巡检区。`FORWARD_ONLY` 仅前进或停车；`REVERSE_ONLY` 仅倒车或停车，通道段保持车头方向，不能掉头后前进。
- `CHANNEL_WITH_PORTALS` 和 `column_id` 指定对应列及其通道外入口，执行端必须维护这些范围，目标点列表本身不能阻止导航抄近路。
- 所有段仍约定 `stop_at_goal=true`。INSPECT 的成功反馈必须同时代表到位及识别、播报完成；退回或经过已检区不播报。
- 无法到达、无法满足进退模式等情况返回失败；不自动跳过任务。
- JSONL 的 `plan_only=true` 表示只是待执行目标，无实车验证。`start_x/start_y` 是计划起点，不是实时定位值。

普通 move_base 目标不会自动理解这些扩展字段，仍需执行层对接。更换坐标文件只影响之后生成的计划，不修改执行中的计划。

## 反馈和编译

`session.c` 保留反馈状态机：

```c
MotionSession session;
motion_session_begin(&session, &plan, new_mission_id);
const MotionCommand *cmd = motion_session_current(&session);
/* 下发 cmd，收到真实反馈后： */
motion_session_ack(&session, feedback_mission_id, feedback_task_id, success);
```

成功才推进；错误或旧任务编号不推进；失败停止。会话持有计划指针，执行期间不能释放或修改该计划。C++ ROS 包装层使用 `extern "C"` 引用 C 接口，.c 文件按 C 编译。

双击 `build.cmd` 编译 V6 并运行检查：1364 种拓扑布局，2728 次运动检查（每种布局使用原始和旋转地图），以及缺点、重名、非法数值、几何错误、元数据错误与导入失败不覆盖原内存数据的验证。这些不是实车或导航仿真测试。
