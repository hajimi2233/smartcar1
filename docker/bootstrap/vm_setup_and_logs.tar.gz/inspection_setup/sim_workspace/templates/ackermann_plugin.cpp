#include <gazebo/gazebo.hh>
#include <gazebo/physics/physics.hh>
#include <gazebo/common/common.hh>
#include <ros/ros.h>
#include <ros/callback_queue.h>
#include <geometry_msgs/Twist.h>
#include <nav_msgs/Odometry.h>
#include <sensor_msgs/JointState.h>
#include <tf/transform_broadcaster.h>
#include <algorithm>
#include <cmath>
#include <memory>

namespace gazebo {
class InspectionAckermann : public ModelPlugin {
  physics::ModelPtr model_;
  physics::JointPtr wheels_[4], steer_[2];
  event::ConnectionPtr update_;
  std::unique_ptr<ros::NodeHandle> nh_;
  ros::CallbackQueue queue_;
  ros::Subscriber sub_;
  ros::Publisher odom_, joints_;
  std::unique_ptr<tf::TransformBroadcaster> tf_;
  double L_, track_, rear_track_, radius_, angle_, torque_, vmax_, accel_, steer_rate_;
  double v_=0, w_=0, applied_v_=0, applied_delta_=0, last_time_=0, last_pub_=0;
  ros::WallTime last_command_;
  static double clamp(double v,double a,double b) { return std::max(a,std::min(b,v)); }
  double read(sdf::ElementPtr s,const std::string &key,double fallback) {
    return s->HasElement(key) ? s->Get<double>(key) : fallback;
  }
  void command(const geometry_msgs::Twist::ConstPtr &m) {
    if (!std::isfinite(m->linear.x)||!std::isfinite(m->angular.z)) {v_=w_=0;return;}
    v_=clamp(m->linear.x,-vmax_,vmax_); w_=m->angular.z;
    last_command_=ros::WallTime::now();
  }
 public:
  void Load(physics::ModelPtr model,sdf::ElementPtr s) override {
    if (!ros::isInitialized()) {gzerr<<"gazebo_ros must initialize ROS first\n";return;}
    model_=model;
    L_=read(s,"wheelbase",.62);track_=read(s,"front_track",.45);
    rear_track_=read(s,"rear_track",.45);radius_=read(s,"wheel_radius",.09);
    angle_=read(s,"max_wheel_angle",.698);torque_=read(s,"wheel_torque",8);
    vmax_=read(s,"max_speed",.35);accel_=read(s,"acceleration",.3);
    steer_rate_=read(s,"steer_rate",.5);
    const char *names[]={"front_left_wheel_joint","front_right_wheel_joint","rear_left_wheel_joint","rear_right_wheel_joint"};
    for (int i=0;i<4;++i) {wheels_[i]=model_->GetJoint(names[i]);if(!wheels_[i]){gzerr<<names[i]<<" missing\n";return;}}
    steer_[0]=model_->GetJoint("front_left_steer_joint");steer_[1]=model_->GetJoint("front_right_steer_joint");
    if(!steer_[0]||!steer_[1]) {gzerr<<"Steering joints missing\n";return;}
    nh_.reset(new ros::NodeHandle("/sim"));nh_->setCallbackQueue(&queue_);
    sub_=nh_->subscribe("cmd_vel",1,&InspectionAckermann::command,this);
    odom_=nh_->advertise<nav_msgs::Odometry>("ground_truth/odom",5);
    joints_=nh_->advertise<sensor_msgs::JointState>("joint_states",5);
    tf_.reset(new tf::TransformBroadcaster());
    last_command_=ros::WallTime::now();last_time_=model_->GetWorld()->GetSimTime().Double();
    update_=event::Events::ConnectWorldUpdateBegin(std::bind(&InspectionAckermann::step,this));
    ROS_INFO("Simulation-only four-wheel drive ready: /sim/cmd_vel; ideal rate-limited steering, assumed torque/mass.");
  }
  void step() {
    queue_.callAvailable(ros::WallDuration(0));
    double now=model_->GetWorld()->GetSimTime().Double(),dt=now-last_time_;last_time_=now;
    if(dt<=0||dt>.1) {v_=w_=applied_v_=applied_delta_=0;last_pub_=now;return;}
    if((ros::WallTime::now()-last_command_).toSec()>.6) {v_=w_=0;}
    double min_R=L_/std::tan(angle_)+track_/2;
    double curvature=std::abs(v_)>.001 ? clamp(w_/v_,-1/min_R,1/min_R) : 0;
    double delta=std::atan(L_*curvature);
    applied_delta_+=clamp(delta-applied_delta_,-steer_rate_*dt,steer_rate_*dt);
    applied_v_+=clamp(v_-applied_v_,-accel_*dt,accel_*dt);
    curvature=std::tan(applied_delta_)/L_;
    double yaw_rate=applied_v_*curvature;
    // Front wheel angles differ, and each stays inside the measured 40 degree bound.
    for(int i=0;i<2;++i) {
      double y=(i==0?1:-1)*track_/2;
      double a=std::atan2(L_*curvature,1-y*curvature);
      // Ideal position servo: rate-limited angular constraint, not calibrated servo dynamics.
      // This avoids force oscillation of lightweight steering links in the ODE solver.
      math::Angle target(clamp(a,-angle_,angle_));
      steer_[i]->SetHighStop(0,target);
      steer_[i]->SetLowStop(0,target);
    }
    for(int i=0;i<4;++i) {
      double y=(i%2==0?1:-1)*(i<2?track_:rear_track_)/2;
      double speed=applied_v_-yaw_rate*y;
      if(i<2) speed=std::copysign(std::hypot(speed,yaw_rate*L_),applied_v_);
      wheels_[i]->SetParam("fmax",0,torque_);
      wheels_[i]->SetParam("vel",0,speed/radius_);
    }
    if(now-last_pub_<.02) return;last_pub_=now;
    auto p=model_->GetWorldPose();auto lv=model_->GetWorldLinearVel();auto av=model_->GetWorldAngularVel();
    ros::Time stamp(now);
    nav_msgs::Odometry od;od.header.stamp=stamp;od.header.frame_id="sim_world";od.child_frame_id="base_footprint";
    od.pose.pose.position.x=p.pos.x;od.pose.pose.position.y=p.pos.y;
    od.pose.pose.orientation.x=p.rot.x;od.pose.pose.orientation.y=p.rot.y;od.pose.pose.orientation.z=p.rot.z;od.pose.pose.orientation.w=p.rot.w;
    auto local=p.rot.RotateVectorReverse(lv);
    od.twist.twist.linear.x=local.x;od.twist.twist.linear.y=local.y;od.twist.twist.angular.z=av.z;
    odom_.publish(od);
    tf::Transform t;t.setOrigin(tf::Vector3(p.pos.x,p.pos.y,0));t.setRotation(tf::Quaternion(p.rot.x,p.rot.y,p.rot.z,p.rot.w));
    tf_->sendTransform(tf::StampedTransform(t,stamp,"sim_world","base_footprint"));
    sensor_msgs::JointState js;js.header.stamp=stamp;
    for(int i=0;i<4;++i){js.name.push_back(wheels_[i]->GetName());js.position.push_back(wheels_[i]->GetAngle(0).Radian());}
    for(int i=0;i<2;++i){js.name.push_back(steer_[i]->GetName());js.position.push_back(steer_[i]->GetAngle(0).Radian());}
    joints_.publish(js);
  }
};
GZ_REGISTER_MODEL_PLUGIN(InspectionAckermann)
}
