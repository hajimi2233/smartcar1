#!/usr/bin/env bash
set -e
cd "$(dirname "$0")/.."
source scripts/source_env.sh
# VirtualBox/Ubuntu 16.04 SVGA3D crashed during model loading; keep the tested fallback.
# Set LIBGL_ALWAYS_SOFTWARE=0 explicitly only when testing a repaired graphics stack.
export LIBGL_ALWAYS_SOFTWARE="${LIBGL_ALWAYS_SOFTWARE:-1}"
sim_gui=true
sim_rviz=true
for sim_arg in "$@"; do
  case "$sim_arg" in
    gui:=*) sim_gui="${sim_arg#gui:=}" ;;
    rviz:=*) sim_rviz="${sim_arg#rviz:=}" ;;
  esac
done
if [ "$sim_gui" != false ] || [ "$sim_rviz" != false ]; then
  # Plain SSH has no DISPLAY; use this user's existing VM desktop, never disable X access control.
  export DISPLAY="${DISPLAY:-:0}"
  if ! xrandr --query >/dev/null 2>&1; then
    echo "Cannot access desktop DISPLAY=$DISPLAY. Log in to the Ubuntu graphical desktop first."
    echo 'For no windows use: bash ~/smartcar_2026_ws/scripts/run_sim.sh gui:=false rviz:=false'
    exit 1
  fi
  echo "Windows will open on the Ubuntu desktop: DISPLAY=$DISPLAY"
fi
exec roslaunch smartcar_bringup simulation.launch "$@"
